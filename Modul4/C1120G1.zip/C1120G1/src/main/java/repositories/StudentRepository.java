package repositories;

import models.Student;

public interface StudentRepository extends CRUDRepository<Student> {
}
